<?php
require_once __DIR__ . '/src/helpers.php';

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['user_id'])) {
    $userToDelete = $_POST['user_id'];

    $sql = "DELETE FROM users WHERE id = $userToDelete";

    if ($conn->query($sql) === TRUE) {
        header("Location: dashboard.php");
        exit();
    } else {
        echo "Error deleting user: " . $conn->error;
    }
} else {
    echo "Invalid request";
}

$conn->close();
?>
