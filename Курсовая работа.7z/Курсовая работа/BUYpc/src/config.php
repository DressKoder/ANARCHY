<?php

const DB_HOST = 'localhost';
const DB_PORT = '3306';
const DB_NAME = 'gg';
const DB_USERNAME = 'root';
const DB_PASSWORD = '';
$DB_HOST = 'localhost';
$DB_PORT = '3306';
$DB_NAME = 'gg';
$DB_USERNAME = 'root';
$DB_PASSWORD = '';
$conn = new mysqli($DB_HOST, $DB_USERNAME, $DB_PASSWORD, $DB_NAME,$DB_PORT);
$user = 'root';
$password = '';
$db = 'gg';
$host = 'localhost';
$port = 3306;
$dbreg = new mysqli($host, $user, $password, $db, $port);
if ($dbreg->connect_error) 
{
    exit("������ ����������: " . $dbreg->connect_error);
}
?>
