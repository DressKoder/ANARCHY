<?php
require_once __DIR__ . '/src/helpers.php';

checkAuth();
$user = currentUser();
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$user_id = $_SESSION['user'];

$sql_role = "SELECT role FROM users WHERE id=?";
$stmt = $conn->prepare($sql_role);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result_role = $stmt->get_result();

if ($result_role->num_rows > 0) {
    $user_role = $result_role->fetch_assoc()['role'];

    if ($user_role === 'admin') {
        echo "<p>Welcome, Admin. You have permissions to edit user data.</p>";
        echo "<h3>User List:</h3>";
            echo "<ul>";
            while ($row = $result_users->fetch_assoc()) {
                echo "<li>ID: " . $row['id'] . ", Username: " . $row['username'] . " 
                      <button onclick='editUser(" . $row['id'] . ")'>Edit</button>
                      <button onclick='confirmDelete(" . $row['id'] . ")'>Delete</button></li>";
            }
            echo "</ul>";
            echo "<button onclick='showAddUserForm()'>Add User</button>";
            echo "</div>";
        } else {
            echo "No registered users.";
        }
    } else {
        echo "<p>Welcome, User. You do not have permissions to edit user data.</p>";
    }


$conn->close();
?>


<!DOCTYPE html>
<html lang="ru" data-theme="light">
<?php include_once __DIR__ . '/components/head.php'?>
<body>
<style>
   .brd {
    position:absolute;
    top: 1px }
  </style>
<div class="card home brd">
    <img
        class="avatar"
        src="<?php echo $user['avatar'] ?>"
        alt="<?php echo $user['name'] ?>"
    >
    <h1>Привет, <?php echo $user['name'] ?>!</h1>
    <form action="/index.html" method="post">
        <button role="button">На главную</button>
    </form>
    <h3>Изменение данных</h3>
        <form action="edit_user.php" method="post">
            <input type="hidden" name="edit_user_id" id="edit_user_id" value="">
            <label for="new_name">Новый логин:</label>
            <input type="text" id="new_name" name="new_name" value="<?php echo $user['name']; ?>" required>

            <label for="new_password">Новый пароль:</label>
            <input type="password" id="new_password" name="new_password" required>

            <button type="submit">Сохранить изменения</button>
        </form>
    <form action="src/actions/logout.php" method="post">
        <button role="button">Выйти из аккаунта</button>
    </form>
     <form action="/edit.php" method="post">
        <button role="button">Админ панель</button>
    </form>
</div>

<?php include_once __DIR__ . '/components/scripts.php' ?>
</body>
</html>