<?php
require_once __DIR__ . '/src/helpers.php';

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['username']) && isset($_POST['new_password'])) {
    $newUsername = $_POST['username'];
    $newPassword = password_hash($_POST['new_password'], PASSWORD_DEFAULT);

    $sql = "INSERT INTO users (username, password) VALUES ('$newUsername', '$newPassword')";

    if ($conn->query($sql) === TRUE) {
        header("Location: dashboard.php");
        exit();
    } else {
        echo "Error adding new user: " . $conn->error;
    }
} else {
    echo "Invalid request";
}

$conn->close();
?>
