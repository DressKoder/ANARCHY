<?php
require_once __DIR__ . '/src/helpers.php';
$pdo = getPDO();

    if (!isset($_SESSION['user'])) {
        return false;
    }

    $user_id = $_SESSION['user']['id'] ?? null;


$result_role = $conn->query("SELECT role FROM users WHERE id=$user_id");

if ($result_role->num_rows > 0) {
    $user_role = $result_role->fetch_assoc()['role'];

    if ($user_role == 'admin') {
        $sql_users = "SELECT id, name FROM users";
        $result_users = $conn->query($sql_users);

        if ($result_users->num_rows > 0) {
            echo "<div class='admin-panel'>";
            echo "<h3>User List:</h3>";
            echo "<ul>";
            while ($row = $result_users->fetch_assoc()) {
                echo "<li>ID: " . $row['id'] . ", Username: " . $row['name'] . " 
                      <button onclick='editUser(" . $row['id'] . ")'>Edit</button>
                      <button onclick='confirmDelete(" . $row['id'] . ")'>Delete</button></li>";
            }
            echo "</ul>";
            echo "<button onclick='showAddUserForm()'>Add User</button>";
            echo "</div>";
        } else {
            echo "No registered users.";
        }}
    } else 
    {
        echo "<p>Welcome, User. You do not have permissions to edit user data.</p>";
        
    }


$conn->close();
?>